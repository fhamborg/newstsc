The following files are part of the dataset "NewsTSC" described in our paper. 
If you use the dataset or parts of it, please cite the following paper:

@InProceedings{Hamborg2021,
  author    = {Hamborg, Felix and Donnay, Karsten and Gipp, Bela},
  title     = {Towards Target-dependent Sentiment Classification in News Articles},
  booktitle = {Proceedings of the iConference 2021},
  year      = {2021},
  month     = {Mar.},
  location  = {Beijing, China (Virtual Event)},
}
